a = 4
b = 6
def add(x, y):
    print x + y
    return 0